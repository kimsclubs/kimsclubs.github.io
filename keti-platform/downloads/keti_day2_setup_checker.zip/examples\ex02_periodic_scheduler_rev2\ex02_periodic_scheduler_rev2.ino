/*
  Day 2 Example 02: Periodic scheduler with micros()
  Board: Arduino Nano 33 BLE Rev2

  Serial output:
    COUNT,<millis>,<tick_count>
*/

const uint32_t SERIAL_BAUD = 115200;
const uint32_t TICK_INTERVAL_US = 1000;  // 1 ms

uint32_t nextTickUs = 0;
uint32_t tickCount = 0;
uint32_t lastPrintMs = 0;
bool ledState = false;

void setup() {
  Serial.begin(SERIAL_BAUD);
  pinMode(LED_BUILTIN, OUTPUT);
  nextTickUs = micros();
}

void loop() {
  const uint32_t nowUs = micros();

  if ((int32_t)(nowUs - nextTickUs) >= 0) {
    nextTickUs += TICK_INTERVAL_US;
    tickCount++;

    if ((tickCount % 500) == 0) {
      ledState = !ledState;
      digitalWrite(LED_BUILTIN, ledState ? HIGH : LOW);
    }
  }

  const uint32_t nowMs = millis();
  if (nowMs - lastPrintMs >= 1000) {
    lastPrintMs = nowMs;
    Serial.print("COUNT,");
    Serial.print(nowMs);
    Serial.print(",");
    Serial.println(tickCount);
  }
}
