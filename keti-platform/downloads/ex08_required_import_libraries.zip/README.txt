KETI Day2 Example 08 - Arduino IDE Import Libraries

Use these ZIP files with:

Arduino IDE > Sketch > Include Library > Add .ZIP Library...

Import both ZIP files individually:

1. KETI_EI_Motion_Minimal_import_library.zip
2. Arduino_BMI270_BMM150_import_library.zip

The convenience bundle ex08_required_import_libraries.zip contains the two
import ZIP files above. Extract the bundle first, then import the two inner ZIP
files through Arduino IDE.

Do not import ex08_required_import_libraries.zip directly as an Arduino library.
