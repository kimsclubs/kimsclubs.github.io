const http = require("http");
const fs = require("fs");
const fsp = require("fs/promises");
const path = require("path");
const crypto = require("crypto");
const { spawn } = require("child_process");

const HOST = "127.0.0.1";
const PORT = Number(process.env.KETI_FLASH_HELPER_PORT || 8765);
const ROOT = path.resolve(__dirname, "..");
const WEB_DIR = path.join(ROOT, "web_gui");
const PREBUILT_DIR = path.join(ROOT, "firmware", "prebuilt");
const MANIFEST_PATH = path.join(PREBUILT_DIR, "manifest.json");
const HELPER_VERSION = "0.1.0";

const MIME_TYPES = {
  ".html": "text/html; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".ps1": "text/plain; charset=utf-8",
  ".zip": "application/zip",
  ".png": "image/png",
  ".ico": "image/x-icon"
};

function sendJson(res, statusCode, payload) {
  const body = JSON.stringify(payload, null, 2);
  res.writeHead(statusCode, {
    "Content-Type": "application/json; charset=utf-8",
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "GET,POST,OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type",
    "Cache-Control": "no-store"
  });
  res.end(body);
}

function sendText(res, statusCode, body) {
  res.writeHead(statusCode, {
    "Content-Type": "text/plain; charset=utf-8",
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "GET,POST,OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type",
    "Cache-Control": "no-store"
  });
  res.end(body);
}

function runCommand(command, args, timeoutMs = 45000) {
  return new Promise((resolve) => {
    const startedAt = Date.now();
    const child = spawn(command, args, {
      cwd: ROOT,
      windowsHide: true,
      shell: false
    });

    let stdout = "";
    let stderr = "";
    let timedOut = false;

    const timer = setTimeout(() => {
      timedOut = true;
      child.kill();
    }, timeoutMs);

    child.stdout.on("data", (chunk) => {
      stdout += chunk.toString();
    });
    child.stderr.on("data", (chunk) => {
      stderr += chunk.toString();
    });
    child.on("error", (error) => {
      clearTimeout(timer);
      resolve({
        code: -1,
        stdout,
        stderr: `${stderr}${error.message}`,
        timedOut,
        elapsedMs: Date.now() - startedAt
      });
    });
    child.on("close", (code) => {
      clearTimeout(timer);
      resolve({
        code,
        stdout,
        stderr,
        timedOut,
        elapsedMs: Date.now() - startedAt
      });
    });
  });
}

async function readBodyJson(req) {
  const chunks = [];
  let total = 0;
  for await (const chunk of req) {
    total += chunk.length;
    if (total > 1024 * 1024) {
      throw new Error("Request body too large");
    }
    chunks.push(chunk);
  }
  const text = Buffer.concat(chunks).toString("utf8").trim();
  return text ? JSON.parse(text) : {};
}

async function readManifest() {
  const text = await fsp.readFile(MANIFEST_PATH, "utf8");
  const manifest = JSON.parse(text);
  if (!Array.isArray(manifest.firmware)) {
    throw new Error("Invalid firmware manifest");
  }
  return manifest;
}

function normalizeFirmwarePath(fileName) {
  const candidate = path.resolve(PREBUILT_DIR, fileName);
  const prebuiltRoot = `${path.resolve(PREBUILT_DIR)}${path.sep}`;
  if (!candidate.startsWith(prebuiltRoot)) {
    throw new Error("Firmware path escapes prebuilt directory");
  }
  return candidate;
}

async function sha256File(filePath) {
  const hash = crypto.createHash("sha256");
  const stream = fs.createReadStream(filePath);
  for await (const chunk of stream) {
    hash.update(chunk);
  }
  return hash.digest("hex").toUpperCase();
}

function validatePort(port) {
  const text = String(port || "").trim().toUpperCase();
  if (!/^COM[0-9]{1,3}$/.test(text)) {
    throw new Error("Port must look like COM12");
  }
  return text;
}

async function handlePorts(res) {
  const result = await runCommand("arduino-cli", ["board", "list", "--format", "json"], 12000);
  if (result.code !== 0) {
    const fallback = await runCommand("arduino-cli", ["board", "list"], 12000);
    return sendJson(res, fallback.code === 0 ? 200 : 500, {
      ok: fallback.code === 0,
      format: "text",
      stdout: fallback.stdout,
      stderr: fallback.stderr,
      ports: parseBoardListText(fallback.stdout)
    });
  }

  let raw = null;
  let ports = [];
  try {
    raw = JSON.parse(result.stdout);
    ports = parseBoardListJson(raw);
  } catch (error) {
    return sendJson(res, 200, {
      ok: true,
      format: "json-parse-failed",
      stdout: result.stdout,
      stderr: `${result.stderr}${error.message}`,
      ports: []
    });
  }

  sendJson(res, 200, {
    ok: true,
    format: "json",
    ports,
    raw
  });
}

function parseBoardListJson(raw) {
  const detected = Array.isArray(raw.detected_ports) ? raw.detected_ports : [];
  return detected.map((item) => {
    const port = item.port || {};
    const matches = Array.isArray(item.matching_boards) ? item.matching_boards : [];
    return {
      address: port.address || "",
      protocol: port.protocol || "",
      label: port.label || "",
      boards: matches.map((board) => ({
        name: board.name || "",
        fqbn: board.fqbn || ""
      }))
    };
  }).filter((item) => item.address);
}

function parseBoardListText(text) {
  return text.split(/\r?\n/)
    .map((line) => line.match(/^(COM[0-9]+)\s+/i))
    .filter(Boolean)
    .map((match) => ({ address: match[1].toUpperCase(), protocol: "serial", label: "", boards: [] }));
}

async function handleFirmwares(res) {
  const manifest = await readManifest();
  sendJson(res, 200, { ok: true, ...manifest });
}

async function handleHealth(res) {
  const version = await runCommand("arduino-cli", ["version"], 8000);
  sendJson(res, 200, {
    ok: true,
    helper: "KETI Flash Helper",
    version: HELPER_VERSION,
    root: ROOT,
    arduinoCli: {
      ok: version.code === 0,
      stdout: version.stdout.trim(),
      stderr: version.stderr.trim()
    }
  });
}

async function handleFlash(req, res) {
  const body = await readBodyJson(req);
  const port = validatePort(body.port);
  const firmwareId = String(body.firmwareId || "stage1_lab_console");
  const manifest = await readManifest();
  const firmware = manifest.firmware.find((item) => item.id === firmwareId);

  if (!firmware) {
    return sendJson(res, 404, { ok: false, error: `Unknown firmware id: ${firmwareId}` });
  }

  const firmwarePath = normalizeFirmwarePath(firmware.file);
  const actualHash = await sha256File(firmwarePath);
  if (firmware.sha256 && actualHash !== String(firmware.sha256).toUpperCase()) {
    return sendJson(res, 409, {
      ok: false,
      error: "Firmware SHA-256 mismatch",
      expected: firmware.sha256,
      actual: actualHash
    });
  }

  const fqbn = String(body.fqbn || firmware.fqbn || "arduino:mbed_nano:nano33ble");
  const args = ["upload", "-p", port, "--fqbn", fqbn, "--input-file", firmwarePath];
  const result = await runCommand("arduino-cli", args, 90000);

  sendJson(res, result.code === 0 ? 200 : 500, {
    ok: result.code === 0,
    command: `arduino-cli ${args.join(" ")}`,
    firmware: {
      id: firmware.id,
      version: firmware.version,
      file: firmware.file,
      sha256: actualHash
    },
    port,
    fqbn,
    code: result.code,
    timedOut: result.timedOut,
    elapsedMs: result.elapsedMs,
    stdout: result.stdout,
    stderr: result.stderr
  });
}

async function serveStatic(req, res) {
  const url = new URL(req.url, `http://${HOST}:${PORT}`);
  const requestPath = url.pathname === "/" ? "/index.html" : url.pathname;
  const decodedPath = decodeURIComponent(requestPath);
  const filePath = path.resolve(WEB_DIR, `.${decodedPath}`);
  const webRoot = `${path.resolve(WEB_DIR)}${path.sep}`;

  if (!filePath.startsWith(webRoot)) {
    return sendText(res, 403, "Forbidden");
  }

  try {
    const data = await fsp.readFile(filePath);
    const ext = path.extname(filePath).toLowerCase();
    res.writeHead(200, {
      "Content-Type": MIME_TYPES[ext] || "application/octet-stream",
      "Cache-Control": "no-store"
    });
    res.end(data);
  } catch (error) {
    sendText(res, 404, "Not found");
  }
}

async function route(req, res) {
  if (req.method === "OPTIONS") {
    return sendJson(res, 204, {});
  }

  const url = new URL(req.url, `http://${HOST}:${PORT}`);

  try {
    if (req.method === "GET" && url.pathname === "/api/health") {
      return await handleHealth(res);
    }
    if (req.method === "GET" && url.pathname === "/api/firmwares") {
      return await handleFirmwares(res);
    }
    if (req.method === "GET" && url.pathname === "/api/ports") {
      return await handlePorts(res);
    }
    if (req.method === "POST" && url.pathname === "/api/flash") {
      return await handleFlash(req, res);
    }
    if (req.method === "GET") {
      return await serveStatic(req, res);
    }
    sendJson(res, 405, { ok: false, error: "Method not allowed" });
  } catch (error) {
    sendJson(res, 500, { ok: false, error: error.message });
  }
}

const server = http.createServer(route);

server.listen(PORT, HOST, () => {
  console.log(`KETI Flash Helper ${HELPER_VERSION}`);
  console.log(`GUI:    http://${HOST}:${PORT}/`);
  console.log(`Health: http://${HOST}:${PORT}/api/health`);
});
